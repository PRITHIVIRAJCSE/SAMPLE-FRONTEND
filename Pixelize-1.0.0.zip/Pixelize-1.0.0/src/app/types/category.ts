export type CategoryType = {
  imgSrc: string
  title: string
}
