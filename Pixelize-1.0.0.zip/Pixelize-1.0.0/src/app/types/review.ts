export type ReviewType = {
  imgSrc: string
  name: string
  rating: number
  desc: string
}
