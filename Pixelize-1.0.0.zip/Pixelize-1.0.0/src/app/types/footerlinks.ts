export type Link = {
  label: string
  href: string
}

export type FooterLinkType = {
  section: string
  links: Link[]
}
