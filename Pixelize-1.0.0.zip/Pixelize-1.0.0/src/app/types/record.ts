export type RecordType = {
    imgSrc: string
    digit: string
    desc: string
}