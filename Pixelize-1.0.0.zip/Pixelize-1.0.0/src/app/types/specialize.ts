export type SpecializeType = {
  imgSrc: string
  title: string
  desc: string
}
