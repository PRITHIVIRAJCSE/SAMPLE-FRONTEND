export type HeroType = {
  imgSrc: string
}
