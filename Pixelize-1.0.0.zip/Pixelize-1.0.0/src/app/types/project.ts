export type ProjectType = {
  coverImg: string
  name: string
}
