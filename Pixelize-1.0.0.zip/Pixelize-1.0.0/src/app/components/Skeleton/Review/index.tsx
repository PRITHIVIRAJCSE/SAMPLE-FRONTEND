const ReviewSkeleton = () => {
  return (
    <>
      <div>
        <div
          role='status'
          className='max-w-md animate-pulse overflow-hidden text-center backdrop-blur-md m-3 p-6 bg-white dark:bg-lightdarkblue rounded-lg'>
          <div className='flex items-center gap-5'>
            <svg
              className='w-20 h-20 text-gray-200'
              aria-hidden='true'
              xmlns='http://www.w3.org/2000/svg'
              fill='currentColor'
              viewBox='0 0 20 18'>
              <path d='M18 0H2a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2Zm-5.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm4.376 10.481A1 1 0 0 1 16 15H4a1 1 0 0 1-.895-1.447l3.5-7A1 1 0 0 1 7.468 6a.965.965 0 0 1 .9.5l2.775 4.757 1.546-1.887a1 1 0 0 1 1.618.1l2.541 4a1 1 0 0 1 .028 1.011Z' />
            </svg>
            <div>
              <div className='h-2 w-20 bg-gray-200 rounded-full max-w-[330px] mb-3'></div>
              <div className='h-2 w-36 bg-gray-200 rounded-full max-w-[330px]'></div>
            </div>
          </div>
          <div className='mt-10'>
            <div className='h-2 w-36  bg-gray-200 rounded-full max-w-[300px] mb-2.5'></div>
            <div className='h-2 w-full  bg-gray-200 rounded-full max-w-[330px] mb-2.5'></div>
            <div className='h-2 w-full  bg-gray-200 rounded-full max-w-[330px] mb-2.5'></div>
            <span className='sr-only'>Loading...</span>
          </div>
        </div>
      </div>
    </>
  )
}

export default ReviewSkeleton
